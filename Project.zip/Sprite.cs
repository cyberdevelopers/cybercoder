﻿using System;
using System.Drawing;
using System.Linq;

namespace AiTest
{
  abstract class Sprite
  {
		#region  Public Abstract Methods  

    public abstract CollisionAction GetCollisionAction(Sprite collidedWith);

    public abstract void Move();

		#endregion  Public Abstract Methods  

		#region  Public Methods  

    public Tile GetAdjacentTile(Direction direction)
    {
      Tile result;

      switch (direction)
      {
        case Direction.Up:
          result = this.Map.Tiles[this.Location.X, this.Location.Y - 1];
          break;
        case Direction.Left:
          result = this.Map.Tiles[this.Location.X + 1, this.Location.Y];
          break;
        case Direction.Down:
          result = this.Map.Tiles[this.Location.X, this.Location.Y + 1];
          break;
        case Direction.Right:
          result = this.Map.Tiles[this.Location.X - 1, this.Location.Y];
          break;
        default:
          throw new ArgumentException();
      }

      return result;
    }

    public Direction GetNewDirection(Direction turnDirection)
    {
      Direction result;

      switch (turnDirection)
      {
        case Direction.Left:
          result = this.Direction - 1;
          if (result < Direction.Up)
            result = Direction.Right;
          break;
        case Direction.Right:
          result = this.Direction + 1;
          if (result > Direction.Right)
            result = Direction.Up;
          break;
        default:
          throw new ArgumentException();
      }

      return result;
    }

    public bool IsCollision(Point location, out Sprite sprite)
    {
      sprite = this.Map.Sprites.SingleOrDefault(s => s.Location == location);

      return sprite != null;
    }

		#endregion  Public Methods  

		#region  Public Properties  

    public abstract Color Color { get; }

    public Direction Direction { get; set; }

    public Point Location { get; set; }

    public Map Map { get; set; }

		#endregion  Public Properties  
  }
}
