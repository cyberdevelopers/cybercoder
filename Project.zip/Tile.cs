﻿using System.Drawing;

namespace AiTest
{
  class Tile
  {
		#region  Public Properties  

    public Point Location { get; set; }

    public bool Solid { get; set; }

		#endregion  Public Properties  
  }
}
