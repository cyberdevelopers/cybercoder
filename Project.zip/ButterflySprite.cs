﻿using System.Drawing;

namespace AiTest
{
  // Movement rules sourced from:
  // http://www.elmerproductions.com/sp/peterb/BDCFF/objects/0009.html

  class ButterflySprite : EnemySprite
  {
		#region  Public Constructors  

    public ButterflySprite()
      : base(Direction.Right, Direction.Left)
    {
      this.Direction = Direction.Down;
    }

		#endregion  Public Constructors  

		#region  Public Properties  

    public override Color Color
    {
      get { return Color.FromKnownColor(KnownColor.Goldenrod); }
    }

		#endregion  Public Properties  
  }
}
