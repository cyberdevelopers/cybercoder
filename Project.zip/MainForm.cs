﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace AiTest
{
  public partial class MainForm : Form
  {
		#region  Private Member Declarations  

    private Map _map;
    private Random _seed;
    private Font _symbolFont;

		#endregion  Private Member Declarations  

		#region  Public Constructors  

    public MainForm()
    {
      InitializeComponent();
    }

		#endregion  Public Constructors  

		#region  Protected Overridden Methods  

    protected override void OnLoad(EventArgs e)
    {
      base.OnLoad(e);

      mapPictureBox.Font = new Font("Small Fonts", 6);
      loadMapButton.PerformClick();
    }

		#endregion  Protected Overridden Methods  

		#region  Event Handlers  

    private void addButterflyButton_Click(object sender, EventArgs e)
    {
      this.AddSprite(new ButterflySprite());
    }

    private void addFireflyButton_Click(object sender, EventArgs e)
    {
      this.AddSprite(new FireflySprite());
    }

    private void addPlayerButton_Click(object sender, EventArgs e)
    {
      this.AddSprite(new PlayerSprite());
    }

    private void closeButton_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void loadMapButton_Click(object sender, EventArgs e)
    {
      this.LoadMap(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Maps\map.txt"));
    }

    private void mapPictureBox_MouseClick(object sender, MouseEventArgs e)
    {
      Sprite sprite;

      if (e.Button == MouseButtons.Left)
        sprite = new FireflySprite();
      else
        sprite = new ButterflySprite();

      this.AddSprite(sprite, this.GetLocation(e.X, e.Y));
    }

    private void mapPictureBox_MouseLeave(object sender, EventArgs e)
    {
      positionToolStripStatusLabel.Text = string.Empty;
    }

    private void mapPictureBox_MouseMove(object sender, MouseEventArgs e)
    {
      Point location;

      location = this.GetLocation(e.X, e.Y);

      positionToolStripStatusLabel.Text = string.Format("[{0},{1}]", location.X, location.Y);
    }

    private void mapPictureBox_Paint(object sender, PaintEventArgs e)
    {
      int tileWidth;
      int tileHeight;
      int mapHeight;
      int mapWidth;

      tileWidth = mapPictureBox.ClientSize.Width / _map.Size.Width;
      tileHeight = mapPictureBox.ClientSize.Height / _map.Size.Height;
      mapWidth = (tileWidth * _map.Size.Width) - 1;
      mapHeight = (tileHeight * _map.Size.Height) - 1;

      e.Graphics.FillRectangle(SystemBrushes.Control, mapPictureBox.ClientRectangle);
      e.Graphics.FillRectangle(Brushes.Black, new Rectangle(0, 0, mapWidth, mapHeight));

      for (int x = 0; x < _map.Size.Width; x++)
      {
        // draw a horizontal grid line
        e.Graphics.DrawLine(Pens.Red, new Point((x * tileWidth) - 1, 0), new Point((x * tileWidth) - 1, mapHeight));

        for (int y = 0; y < _map.Size.Height; y++)
        {
          Rectangle cell;

          cell = new Rectangle((x * tileWidth), (y * tileHeight), tileWidth - 1, tileHeight - 1);

          // draw a vertical grid line
          e.Graphics.DrawLine(Pens.Red, new Point(0, (y * tileHeight) - 1), new Point(mapWidth, (y * tileHeight) - 1));

          // indicate the cell type
          if (_map.Tiles[x, y].Solid)
            e.Graphics.FillRectangle(Brushes.Green, cell);

          // draw the cell coordinates
          //e.Graphics.DrawString(string.Format("{0},{1}", x + 1, y + 1), mapPictureBox.Font, Brushes.White, cell.Location);
        }
      }

      // draw the spires
      foreach (Sprite sprite in _map.Sprites)
      {
        RectangleF cell;
        string arrowText;

        cell = new RectangleF((sprite.Location.X * tileWidth), (sprite.Location.Y * tileHeight), tileWidth - 1, tileHeight - 1);

        using (SolidBrush brush = new SolidBrush(sprite.Color))
          e.Graphics.FillRectangle(brush, cell);

        switch (sprite.Direction)
        {
          case Direction.Up:
            arrowText = "á";
            break;
          case Direction.Left:
            arrowText = "à";
            break;
          case Direction.Down:
            arrowText = "â";
            break;
          case Direction.Right:
            arrowText = "ß";
            break;
          default:
            throw new ApplicationException();
        }

        e.Graphics.DrawString(arrowText, _symbolFont, Brushes.White, cell, new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center });
      }
    }

    private void mapPictureBox_Resize(object sender, EventArgs e)
    {
      this.ResetFonts();
    }

    private void newMapButton_Click(object sender, EventArgs e)
    {
      this.CreateNewRandomMap();
    }

    private void nextMoveButton_Click(object sender, EventArgs e)
    {
      this.NextMove();
    }

    private void speedTrackBar_Scroll(object sender, EventArgs e)
    {
      if (speedTrackBar.Value != 0)
      {
        spriteTimer.Interval = speedTrackBar.Value;
        spriteTimer.Start();
      }
      else
        spriteTimer.Stop();
    }

    private void spriteTimer_Tick(object sender, EventArgs e)
    {
      this.NextMove();
    }

		#endregion  Event Handlers  

		#region  Private Methods  

    private void AddSprite(Sprite sprite, Point location)
    {
      sprite.Location = location;
      this.AddSprite(sprite);
    }

    private void AddSprite(Sprite sprite)
    {
      if (sprite.Location.IsEmpty)
        sprite.Location = new Point(_seed.Next(_map.Size.Width - 2) + 1, _seed.Next(_map.Size.Height - 2) + 1);

      sprite.Map = _map;

      _map.Sprites.Add(sprite);

      mapPictureBox.Invalidate();
    }

    private void CreateNewRandomMap()
    {
      // create a new map
      _seed = new Random();
      _map = new Map(new Size(24, 12));
      for (int x = 0; x < _map.Size.Width; x++)
      {
        for (int y = 0; y < _map.Size.Height; y++)
        {
          Tile tile;

          tile = new Tile();
          tile.Location = new Point(x, y);
          tile.Solid = (x == 0 || y == 0 || x == _map.Size.Width - 1 || y == _map.Size.Height - 1 || _seed.Next(10) == 5);

          _map.Tiles[x, y] = tile;
        }
      }

      // make sure we refresh our display
      this.ResetFonts();
    }

    private Point GetLocation(int x, int y)
    {
      int tileWidth;
      int tileHeight;

      tileWidth = mapPictureBox.ClientSize.Width / _map.Size.Width;
      tileHeight = mapPictureBox.ClientSize.Height / _map.Size.Height;

      return new Point(x / tileWidth, y / tileHeight);
    }

    private void LoadMap(string fileName)
    {
      string[] lines;

      lines = File.ReadAllLines(fileName);

      _map = new Map(new Size(lines[0].Length, lines.Length));

      for (int x = 0; x < _map.Size.Width; x++)
      {
        for (int y = 0; y < _map.Size.Height; y++)
        {
          Tile tile;

          tile = new Tile();
          tile.Location = new Point(x, y);
          switch (lines[y].Substring(x, 1))
          {
            case "#":
              tile.Solid = true;
              break;
            case "F":
              this.AddSprite(new FireflySprite(), tile.Location);
              break;
            case "B":
              this.AddSprite(new ButterflySprite(), tile.Location);
              break;
            case "P":
              this.AddSprite(new PlayerSprite(), tile.Location);
              break;
          }

          _map.Tiles[x, y] = tile;
        }
      }

      // make sure we refresh our display
      this.ResetFonts();
    }

    private void NextMove()
    {
      for (int i = _map.Sprites.Count; i > 0; i--)
        _map.Sprites[i - 1].Move();

      mapPictureBox.Invalidate();
    }

    private void ResetFonts()
    {
      if (_symbolFont != null)
        _symbolFont.Dispose();

      if (_map != null)
        _symbolFont = new Font("Wingdings", (mapPictureBox.ClientSize.Height / _map.Size.Height) / 2);

      mapPictureBox.Invalidate();
    }

		#endregion  Private Methods  
  }
}
  