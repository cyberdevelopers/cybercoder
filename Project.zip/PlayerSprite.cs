﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace AiTest
{
  class PlayerSprite : Sprite
  {
		#region  Public Overridden Methods  

    public override CollisionAction GetCollisionAction(Sprite collidedWith)
    {
      return CollisionAction.Explode; // Player dies if it touches any other sprites
    }

    public override void Move()
    {
      // Do nothing, this sprite doesn't automatically move
    }

		#endregion  Public Overridden Methods  

		#region  Public Properties  

    public override Color Color
    {
      get { return Color.Aquamarine; }
    }

		#endregion  Public Properties  
  }
}
