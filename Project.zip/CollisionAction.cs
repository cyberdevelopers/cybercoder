﻿
namespace AiTest
{
  enum CollisionAction
  {
    None,
    Explode
  }
}
