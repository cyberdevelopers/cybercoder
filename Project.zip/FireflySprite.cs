﻿using System.Drawing;

namespace AiTest
{
  /*
    Movement rules sourced from
    http://www.elmerproductions.com/sp/peterb/BDCFF/objects/0008.html

    if (space to the firefly's left is empty) then
        turn 90 degrees to firefly's left;
        move one space in this new direction; 
    } else if (space ahead is empty) then
        move one space forwards; 
    } else {
        turn 90 degrees to the firefly's right;
        _do not move_;
    }
   */

  class FireflySprite : EnemySprite
  {
		#region  Public Constructors  

    public FireflySprite()
      : base(Direction.Left, Direction.Right)
    {
      this.Direction = Direction.Right;
    }

		#endregion  Public Constructors  

		#region  Public Properties  

    public override System.Drawing.Color Color
    {
      get { return Color.FromKnownColor(KnownColor.Firebrick); }
    }

		#endregion  Public Properties  
  }
}
