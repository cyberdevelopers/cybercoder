﻿using System.Drawing;
using System.Collections.Generic;

namespace AiTest
{
  class Map
  {
		#region  Private Member Declarations  

    private List<Sprite> _sprites;

		#endregion  Private Member Declarations  

		#region  Public Constructors  

    public Map(Size size)
    {
      this.Size = size;
      this.Tiles = new Tile[size.Width, size.Height];
      this.Sprites = new List<Sprite>();
    }

		#endregion  Public Constructors  

		#region  Public Methods  

    public bool IsScenery(Point location)
    {
      return !this.IsScenery(this.Tiles[location.X, location.Y]);
    }

    public bool IsScenery(Tile tile)
    {
      return tile.Solid;
    }

		#endregion  Public Methods  

		#region  Public Properties  

    public Size Size { get; set; }

    public List<Sprite> Sprites
    {
      get { return _sprites; }
      set { _sprites = value; }
    }

    public Tile[,] Tiles { get; set; }

		#endregion  Public Properties  
  }
}
