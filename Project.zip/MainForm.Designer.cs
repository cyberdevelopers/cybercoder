﻿namespace AiTest
{
  partial class MainForm
  {

    private System.Windows.Forms.Button addButterflyButton;
    private System.Windows.Forms.Button addFireflyButton;
    private System.Windows.Forms.Button addPlayerButton;
    private System.Windows.Forms.Button closeButton;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button loadMapButton;
    private System.Windows.Forms.PictureBox mapPictureBox;
    private System.Windows.Forms.Button newMapButton;
    private System.Windows.Forms.Button nextMoveButton;
    private System.Windows.Forms.ToolStripStatusLabel positionToolStripStatusLabel;
    private System.Windows.Forms.TrackBar speedTrackBar;
    private System.Windows.Forms.Timer spriteTimer;
    private System.Windows.Forms.StatusStrip statusStrip1;
    private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;


    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }

      if (_symbolFont != null)
        _symbolFont.Dispose();

      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.mapPictureBox = new System.Windows.Forms.PictureBox();
      this.newMapButton = new System.Windows.Forms.Button();
      this.closeButton = new System.Windows.Forms.Button();
      this.addFireflyButton = new System.Windows.Forms.Button();
      this.addButterflyButton = new System.Windows.Forms.Button();
      this.spriteTimer = new System.Windows.Forms.Timer(this.components);
      this.speedTrackBar = new System.Windows.Forms.TrackBar();
      this.nextMoveButton = new System.Windows.Forms.Button();
      this.statusStrip1 = new System.Windows.Forms.StatusStrip();
      this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
      this.positionToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
      this.loadMapButton = new System.Windows.Forms.Button();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.addPlayerButton = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.mapPictureBox)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.speedTrackBar)).BeginInit();
      this.statusStrip1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      // 
      // mapPictureBox
      // 
      this.mapPictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.mapPictureBox.Location = new System.Drawing.Point(12, 12);
      this.mapPictureBox.Name = "mapPictureBox";
      this.mapPictureBox.Size = new System.Drawing.Size(665, 456);
      this.mapPictureBox.TabIndex = 0;
      this.mapPictureBox.TabStop = false;
      this.mapPictureBox.MouseLeave += new System.EventHandler(this.mapPictureBox_MouseLeave);
      this.mapPictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mapPictureBox_MouseMove);
      this.mapPictureBox.Resize += new System.EventHandler(this.mapPictureBox_Resize);
      this.mapPictureBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.mapPictureBox_MouseClick);
      this.mapPictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.mapPictureBox_Paint);
      // 
      // newMapButton
      // 
      this.newMapButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.newMapButton.Location = new System.Drawing.Point(6, 19);
      this.newMapButton.Name = "newMapButton";
      this.newMapButton.Size = new System.Drawing.Size(112, 23);
      this.newMapButton.TabIndex = 0;
      this.newMapButton.Text = "Random Map";
      this.newMapButton.UseVisualStyleBackColor = true;
      this.newMapButton.Click += new System.EventHandler(this.newMapButton_Click);
      // 
      // closeButton
      // 
      this.closeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.closeButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.closeButton.Location = new System.Drawing.Point(732, 445);
      this.closeButton.Name = "closeButton";
      this.closeButton.Size = new System.Drawing.Size(75, 23);
      this.closeButton.TabIndex = 3;
      this.closeButton.Text = "Close";
      this.closeButton.UseVisualStyleBackColor = true;
      this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
      // 
      // addFireflyButton
      // 
      this.addFireflyButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.addFireflyButton.Location = new System.Drawing.Point(6, 19);
      this.addFireflyButton.Name = "addFireflyButton";
      this.addFireflyButton.Size = new System.Drawing.Size(112, 23);
      this.addFireflyButton.TabIndex = 0;
      this.addFireflyButton.Text = "Add Firefly";
      this.addFireflyButton.UseVisualStyleBackColor = true;
      this.addFireflyButton.Click += new System.EventHandler(this.addFireflyButton_Click);
      // 
      // addButterflyButton
      // 
      this.addButterflyButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.addButterflyButton.Location = new System.Drawing.Point(6, 48);
      this.addButterflyButton.Name = "addButterflyButton";
      this.addButterflyButton.Size = new System.Drawing.Size(112, 23);
      this.addButterflyButton.TabIndex = 1;
      this.addButterflyButton.Text = "Add Butterfly";
      this.addButterflyButton.UseVisualStyleBackColor = true;
      this.addButterflyButton.Click += new System.EventHandler(this.addButterflyButton_Click);
      // 
      // spriteTimer
      // 
      this.spriteTimer.Enabled = true;
      this.spriteTimer.Interval = 1000;
      this.spriteTimer.Tick += new System.EventHandler(this.spriteTimer_Tick);
      // 
      // speedTrackBar
      // 
      this.speedTrackBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.speedTrackBar.LargeChange = 100;
      this.speedTrackBar.Location = new System.Drawing.Point(6, 32);
      this.speedTrackBar.Maximum = 1000;
      this.speedTrackBar.Name = "speedTrackBar";
      this.speedTrackBar.Size = new System.Drawing.Size(112, 45);
      this.speedTrackBar.SmallChange = 10;
      this.speedTrackBar.TabIndex = 1;
      this.speedTrackBar.TickFrequency = 100;
      this.speedTrackBar.Value = 1000;
      this.speedTrackBar.Scroll += new System.EventHandler(this.speedTrackBar_Scroll);
      // 
      // nextMoveButton
      // 
      this.nextMoveButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.nextMoveButton.Location = new System.Drawing.Point(6, 83);
      this.nextMoveButton.Name = "nextMoveButton";
      this.nextMoveButton.Size = new System.Drawing.Size(112, 23);
      this.nextMoveButton.TabIndex = 2;
      this.nextMoveButton.Text = "Next Move";
      this.nextMoveButton.UseVisualStyleBackColor = true;
      this.nextMoveButton.Click += new System.EventHandler(this.nextMoveButton_Click);
      // 
      // statusStrip1
      // 
      this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.positionToolStripStatusLabel});
      this.statusStrip1.Location = new System.Drawing.Point(0, 471);
      this.statusStrip1.Name = "statusStrip1";
      this.statusStrip1.Size = new System.Drawing.Size(819, 22);
      this.statusStrip1.TabIndex = 4;
      this.statusStrip1.Text = "statusStrip1";
      // 
      // toolStripStatusLabel1
      // 
      this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
      this.toolStripStatusLabel1.Size = new System.Drawing.Size(804, 17);
      this.toolStripStatusLabel1.Spring = true;
      // 
      // positionToolStripStatusLabel
      // 
      this.positionToolStripStatusLabel.Name = "positionToolStripStatusLabel";
      this.positionToolStripStatusLabel.Size = new System.Drawing.Size(0, 17);
      // 
      // loadMapButton
      // 
      this.loadMapButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.loadMapButton.Location = new System.Drawing.Point(6, 48);
      this.loadMapButton.Name = "loadMapButton";
      this.loadMapButton.Size = new System.Drawing.Size(112, 23);
      this.loadMapButton.TabIndex = 1;
      this.loadMapButton.Text = "Load Map";
      this.loadMapButton.UseVisualStyleBackColor = true;
      this.loadMapButton.Click += new System.EventHandler(this.loadMapButton_Click);
      // 
      // groupBox1
      // 
      this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.groupBox1.Controls.Add(this.newMapButton);
      this.groupBox1.Controls.Add(this.loadMapButton);
      this.groupBox1.Location = new System.Drawing.Point(683, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(124, 83);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Map";
      // 
      // groupBox2
      // 
      this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.groupBox2.Controls.Add(this.addPlayerButton);
      this.groupBox2.Controls.Add(this.addFireflyButton);
      this.groupBox2.Controls.Add(this.addButterflyButton);
      this.groupBox2.Location = new System.Drawing.Point(683, 101);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(124, 112);
      this.groupBox2.TabIndex = 1;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Elements";
      // 
      // groupBox3
      // 
      this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.groupBox3.Controls.Add(this.label1);
      this.groupBox3.Controls.Add(this.speedTrackBar);
      this.groupBox3.Controls.Add(this.nextMoveButton);
      this.groupBox3.Location = new System.Drawing.Point(683, 219);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(124, 117);
      this.groupBox3.TabIndex = 2;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Movement";
      // 
      // addPlayerButton
      // 
      this.addPlayerButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.addPlayerButton.Location = new System.Drawing.Point(6, 77);
      this.addPlayerButton.Name = "addPlayerButton";
      this.addPlayerButton.Size = new System.Drawing.Size(112, 23);
      this.addPlayerButton.TabIndex = 2;
      this.addPlayerButton.Text = "Add Player";
      this.addPlayerButton.UseVisualStyleBackColor = true;
      this.addPlayerButton.Click += new System.EventHandler(this.addPlayerButton_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(6, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(41, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Speed:";
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.CancelButton = this.closeButton;
      this.ClientSize = new System.Drawing.Size(819, 493);
      this.Controls.Add(this.groupBox3);
      this.Controls.Add(this.groupBox2);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.statusStrip1);
      this.Controls.Add(this.closeButton);
      this.Controls.Add(this.mapPictureBox);
      this.Name = "MainForm";
      this.Text = "AiTest";
      ((System.ComponentModel.ISupportInitialize)(this.mapPictureBox)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.speedTrackBar)).EndInit();
      this.statusStrip1.ResumeLayout(false);
      this.statusStrip1.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
  }
}

