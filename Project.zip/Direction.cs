﻿
namespace AiTest
{
  enum Direction
  {
    Up,
    Left,
    Down,
    Right
  }
}
